<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\User;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function parent(){
        $events = Event::latest()->paginate(50);
        $users = User::latest()->select(['name','id'])->get();
        return view('admin.event.index',compact('events','users'));
    }
    public function store(Request $request){
        $request->validate([
            'body' => 'required',
            'title' => 'required',
        ]);
        Event::create([
            'title' => $request->title,
            'body' => $request->body,
            'type' => 0,
            'user_id' => auth()->user()->id,
            'customer_id' => $request->user_id,
        ]);
        return redirect()->back()->with([
            'message' => 'اعلان با موفقیت اضافه شد'
        ]);
    }
    public function edit(Request $request){
        return Event::where('id' , $request->event)->first();
    }
    public function update(Request $request){
        $request->validate([
            'body' => 'required',
            'title' => 'required',
        ]);
        Event::where('id' , $request->event)->update([
            'title' => $request->title,
            'body' => $request->body,
            'type' => 100,
            'customer_id' => $request->user_id,
        ]);
        return redirect()->back()->with([
            'message' => 'اعلان با موفقیت ویرایش شد'
        ]);
    }
    public function delete(Request $request , Event $event){
        $event->delete();
        return redirect()->back()->with([
            'message' => 'اعلان با موفقیت حذف شد'
        ]);
    }
}
